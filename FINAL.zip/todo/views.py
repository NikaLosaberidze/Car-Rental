from django.shortcuts import render, redirect
from .models import  Car
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView, FormView
from django.urls import reverse_lazy

# login / logout
from django.contrib.auth.views import LoginView

# mixins
from django.contrib.auth.mixins import LoginRequiredMixin

# registration
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login




class RegisterPage(FormView):
    template_name = 'todo/register.html'
    form_class =UserCreationForm
    success_url = reverse_lazy('login')


    def form_valid(self, form):
        user = form.save()

        if user:
            login(self.request, user)

        return super().form_valid(form)

    def get(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('cars')


        return super().get(request, *args, **kwargs)


class CustomLoginView(LoginView):
    template_name = 'todo/login.html'


    def get(self, request, *args, **kwargs):
        if self.request.user.is_authenticated:
            return redirect('cars')


        return super().get(request, *args, **kwargs)


    def get_success_url(self):
        return reverse_lazy('cars')
    

    

class CarList(LoginRequiredMixin, ListView):
    model = Car
    context_object_name = 'cars'


    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        search_input = self.request.GET.get('search_area') or ''

        if search_input:
            context['cars'] = context['cars'].filter(brand__startswith=search_input)
            context['search_input'] = search_input
        
        context['user'] = self.request.user

        return context
    




class CarDetail(LoginRequiredMixin, DetailView):
    model = Car
    template_name = "todo/car.html"
    context_object_name = 'car'




class CarCreate(LoginRequiredMixin, CreateView):
    model = Car
    fields = ['brand', 'model', 'year', 'day_price', 'car_space', 'transmission', 'city', 'fuel_tank', 'image1', 'image2', 'image3']
    # fields = '__all__'
    success_url = reverse_lazy('cars')

    
    def form_valid(self, form):
        form.instance.user = self.request.user

        return super().form_valid(form)




class CarUpdate(LoginRequiredMixin, UpdateView):
    model = Car
    fields = ['brand', 'model', 'year', 'day_price', 'car_space', 'transmission', 'city', 'fuel_tank', 'image1', 'image2', 'image3']
    success_url = reverse_lazy('cars')
    template_name = 'todo/car_form_update.html'

    

class CarDelete(LoginRequiredMixin, DeleteView):
    model = Car
    context_object_name = 'car'
    template_name = "todo/car_delete.html"
    success_url = reverse_lazy('cars')