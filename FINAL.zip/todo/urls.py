from django.urls import path
from . import views
from django.contrib.auth.views import LogoutView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.CarList.as_view(), name='cars'),
    path('car/<int:pk>', views.CarDetail.as_view(), name='car'),
    path('car_create/', views.CarCreate.as_view(), name='car_create'),
    path('car_update/<int:pk>/', views.CarUpdate.as_view(), name='car_update'),
    path('car_delete/<int:pk>/', views.CarDelete.as_view(), name='car_delete'),
    path('login/', views.CustomLoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='cars'), name='logout'),
    path('register/', views.RegisterPage.as_view(), name='register'),
]

urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)



# 127.0.0.1:8000/