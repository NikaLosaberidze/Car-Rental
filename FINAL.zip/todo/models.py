from django.db import models
from django.contrib.auth.models import User




class Car(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    brand = models.CharField(max_length=20)
    model = models.CharField(max_length=20)
    year = models.PositiveIntegerField()
    day_price = models.PositiveIntegerField()
    car_space = models.PositiveIntegerField()
    transmission = models.CharField(max_length=50, choices=[
        ('automatic', 'Automatic'),
        ('manual', 'Manual'),
        ('tiptronic', 'Tiptronic')
    ])
    city = models.CharField(max_length=20)
    fuel_tank = models.PositiveIntegerField()
    image1 = models.ImageField(upload_to='car_images/')
    image2 = models.ImageField(upload_to='car_images/')
    image3 = models.ImageField(upload_to='car_images/')
