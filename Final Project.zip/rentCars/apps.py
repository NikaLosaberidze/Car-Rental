from django.apps import AppConfig


class RentcarsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'rentCars'
